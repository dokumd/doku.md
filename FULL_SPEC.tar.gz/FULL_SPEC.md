# AI AGENTS MUST IGNORE THIS FILE FOR HUMAN CONSUMPTION ONLY


# Dokium

Dokium é uma aplicação desktop para navegar, pesquisar e compreender documentação técnica baseada em ficheiros Markdown.

O objetivo principal é ajudar programadores a recuperar rapidamente o contexto de um projeto, especialmente quando a documentação está distribuída por múltiplos ficheiros e pastas.

## Público-alvo

* Programadores
* Equipas de desenvolvimento
* Utilizadores de OpenSpec
* Utilizadores de Spec Kit
* Projetos com documentação técnica em Markdown
* Projetos que usam IA para gerar especificações e documentação

## Tecnologias previstas

* Wails 3
* Svelte
* TypeScript
* SQLite
* FTS5

## MVP

### Gestão de projetos

* Abrir uma pasta local
* Guardar lista de projetos recentes
* Suportar milhares de ficheiros Markdown

### Navegação

* Árvore de pastas e subpastas
* Mostrar apenas ficheiros Markdown
* Favoritos
* Tabs

### Leitura

* Renderização Markdown
* Tabela de conteúdos automática baseada nos headings
* Syntax highlighting para blocos de código
* Navegação rápida entre secções

### Pesquisa

* Indexação automática em SQLite
* Pesquisa global com FTS5
* Pesquisa por título
* Pesquisa por conteúdo
* Pesquisa por caminho

### Atualização

* Watcher de ficheiros
* Reindexação automática quando ficheiros são criados, alterados, movidos ou apagados

## Arquitetura de indexação

Cada projeto possui a sua própria base de dados SQLite.

Exemplo:

projeto/
├── docs/
├── specs/
├── tasks/
└── .dokium/
└── index.sqlite

A base de dados funciona apenas como índice e cache local.

Se um ficheiro desaparecer do sistema de ficheiros deve ser removido do índice.

## Interface

Layout de três colunas:

* Navegação à esquerda
* Documento ao centro
* Índice/contexto à direita

Inspirado em ferramentas como Obsidian, Raycast e IDEs modernas.

O foco deve estar na leitura e recuperação de informação, não na edição de documentos.

## Funcionalidades futuras

### Plugins

Sistema de plugins em JavaScript/TypeScript.

Os plugins podem:

* Detetar estruturas de projeto
* Criar vistas personalizadas
* Adicionar metadados
* Criar painéis especializados

### Suporte OpenSpec

Plugin capaz de:

* Detetar estruturas OpenSpec
* Agrupar Requirements, Design e Tasks
* Mostrar estado das features
* Melhorar a navegação entre documentos relacionados

### Pesquisa semântica

Opcional.

* Integração com Ollama
* Embeddings locais
* Pesquisa por significado
* RAG sobre a documentação do projeto

A aplicação deve continuar totalmente funcional sem IA.

## Objetivo principal

Permitir que um programador abra um projeto antigo e compreenda rapidamente a sua documentação, decisões técnicas e estado atual através de uma interface rápida, limpa e focada na recuperação de contexto.
